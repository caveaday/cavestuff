# Validation record — 0.4.0

Baseline: Walls tag `v2.2.4`, commit `8428c2ba8ecde662753e4437b3f6d8ee1e783467`. Validation performed on Windows x64 GNU with Rust 1.99.1.

## Automated checks

| Check | Result |
| --- | --- |
| `cargo test --locked --release` | 126 integration tests: 3 CLI workflows, 30 core, 6 editor, 10 exchange/project, 19 GPS/3D/print, 5 parser compatibility, 2 print-format/metafile, 6 advanced review, 9 SVG, 3 upstream/export, 4 original-executable comparisons, 7 viewer/GPS extensions, 5 original-workfile, 4 fresh-generation and 13 legacy-workflow |
| `cargo clippy --locked --all-targets --all-features -- -D warnings` | Passed |
| `cargo fmt --all -- --check` | Passed |
| Release build with desktop feature | CLI and desktop executables built for Windows x64 GNU |

The end-to-end CLI test runs all 11 text export formats, parses their structured output, reopens SVG and VRML, merges the original tutorial artwork, generates map/station/vector/traverse PDFs, archives and extracts a WPJ, reimports SEF, converts GPX into a WPJ and compiles it to geographic output, and verifies invalid arguments fail.

The test suite also covers analytic least-squares solutions and constraints; covariance/best-correction and F-ratio calculations; review undo/redo and revision signatures; SEF fixed/delimited formats; Compass DAT/MAK namespacing, links and fixes; project branches/implicit segments; child references in other grids/datums; normalized SRV measurements and variances; archive paths/overwrite guards; Garmin framing and a simulated transfer state machine; NMEA checksums, UTC and midnight; GPX segments; passage meshes; scoped VRML transforms/DEF/USE/concave polygons; near-plane triangle clipping; tiled map scales and PDF cross-reference offsets.

## Original project checks

| Project | Named stations | Survey shots | Map adjustment |
| --- | ---: | ---: | --- |
| Tutorial | 14 | 15 | 13 eligible control vectors; at least 70 adjusted artwork objects; no missing stations; adjusted SVG reopens |
| Kaua North Maze | 990 | 1,492 | 1,455 eligible control vectors; 4,272 adjusted artwork objects; no missing stations |

## Original-executable numerical comparisons

Unchanged copies of Tutorial and Kaua were compiled in **Walls Project Editor 2.2.4.0 2026-09-27**. The executable's SHA-256 is `74e28920ac925c36bcf9438bd17bd0cfb9fb227f68ea3a3d45db7f3be69d795`. After closing each project, NTP/NTV/NTS numeric fields were decoded using upstream `netlib.h` and `wnetdbf.c`. Observations were matched by source filename and line. The golden JSON files record this provenance; tests do not require the original program.

Regression tests compare all **1,004 named stations**, **1,510 observations including fixes**, and **1,083 original statistical traverses** (6 Tutorial and 1,077 Kaua). Checks cover raw E/N/U measurements, float states, assigned variances, adjusted coordinates, traverse grouping, network variances, F-ratios and system sums of squares. Kaua's maximum observed coordinate difference was below `5e-11` metres on this Windows build; its regression tolerance is `1e-7` metres. Tutorial's tolerance is `1e-6` metres. These results apply to these fixtures.

The comparisons corrected magnetic date/float rounding, reference-datum handling in magnetic synthesis, RMS variance conversion, pendant-junction traverse grouping, retained variances for floated observations and F-test system boundaries. An analytic regression also checks that floating a traverse moves its attached side branch correctly.

Kaua's original Adjusted Branch Totals reports adjusted length **7,658.92 m**, horizontal length **7,589.66 m** and vertical length **559.40 m**. Rust reproduces these to the dialog's 0.01 m precision. Measured and adjusted lengths are stored separately. The compiler's 492 horizontal and 499 vertical loops remain consistent with review totals.

Two-source SVG tests merge independently framed maps, rename colliding IDs and definition references, retain primary survey anchors once, and reopen the result for later adjustment. The original Illustrator tutorial map also passes. Secondary stylesheets must first be expanded to inline styles; the program rejects them rather than silently altering their meaning. Printing tests check symbol color, flag legends, notes, annotation reports and display toggles.

## Visual and hardware checks

The tutorial PDF was rendered with Poppler and inspected. Nearby labels were initially overlapping; placement was revised and the result rendered and inspected again. The latest flag/note/legend layout was also rendered and inspected: symbols, entrance notes, the legend and adjusted length summary are visible. Poppler emitted missing display-font warnings for Symbol/ArialUnicode fallback fonts; the generated document uses Courier/WinAnsi.

The desktop executable launches and exposes a window. Although the automation helper returned a black capture and `failed to activate captured window`, the user confirmed that application controls are visible on their screen. This confirms rendering for that build; detailed interactive feature acceptance remains **unverified**. No physical receiver or printer was exercised. Original executables are excluded. Generated Tutorial workfiles and Kaua NTA are included only as regression fixtures; see NOTICE.md.

VRML regressions cover material scoping, per-face/indexed/per-vertex colours, transparency, coloured export/reimport, line-only scenes, interpolation at the camera clipping plane, and VRML2 appearance fields after geometry. Primitive tests check positive signed volumes and dimensions for box/sphere/cylinder/cone meshes, cap selection and part colours, transformed geometry and invalid sizes. These are automated geometry/material checks; independent interactive desktop acceptance remains outstanding.

The 0.3 tutorial map PDF and page 2 of the 20-page Kaua station report were rendered with Poppler and inspected. The map shows styled annotations/legend and the report repeats its aligned column headings. Textured-room and tutorial stereo PNGs were also inspected. A reversed default light direction initially left front-facing passages too dark; it was corrected and the images regenerated and inspected again. This is offscreen renderer validation, not interactive desktop acceptance.

## Version 0.3 regression coverage

Original workfile checks verify DBF field access, NTA multi-leaf prefix compression, prefix-qualified observations, notes/flags/LRUD, stored coordinates, saved plan/profile metadata, byte-identical bundle copying, overwrite refusal and dynamic H/V float save/reimport. Raw NTV flags remain intact while NTS overrides carry saved review state. Component bounds are updated after coordinate changes. Failed review updates leave the in-memory bundle unchanged; failed copy writes remove only files created by that copy attempt. Reimport is tested in Rust; edited-bundle acceptance in the original application is not yet established.

Editor tests cover independent dirty tabs, duplicate open behaviour, close guards/save all, UTF-8 BOM/CRLF and Windows-1252 output, external disk changes, Unicode byte offsets and whole-word search in selected text, reversible commands and original forward/reverse station auto-sequencing. Existing survey saves now use temporary-file replacement after successful write/sync.

Viewer tests check crossing opaque faces at independently visible pixels regardless of draw order, near-plane clipping, all six rendering modes, stereo dimensions and invalid cameras. Texture tests cover embedded SFImage, local VRML2 URL alternatives with spaces, reordered appearance fields, UV transforms and image pixel preservation across VRML export/reimport. Material tests retain emissive/specular colours and shininess arrays. PNG output is decoded in the CLI workflow test. These tests do not establish optical stereo comfort or old OpenGL lighting equivalence.

GPS tests cover named-waypoint/radius selection, track breaks, no joining across rejected sections, UTC time bounds, timezone CSV output, ISO8601 numeric offsets and malformed timestamps. Simulated Garmin framing/transfer tests remain active. No receiver is connected.

Printing checks validate report paper/font settings and invalid margins, preset defaults/CLI precedence, PDF output, EMF type/signature/physical frame and WMF placeable header/checksum/units. Metafile generation invokes in-memory Windows GDI and does not spool a physical page.

## Version 0.4 regression coverage

Fresh workfiles are generated without fixture templates. Tutorial and Kaua reimport with stored coordinates, raw measurements, dates, prefix/segment identities, annotations and statistical traverses. Kaua checks independently follow every emitted NTV chain and compare all 1,077 NTS assigned/network variance pairs against the original executable's goldens. A synthetic 12,000-segment index exercises multiple TRX branch levels through independent branch descent, plus 3,000 duplicate LRUD keys. Fixed/disconnected components, bridges, source aliases, spray shots and repeated LRUDs are included.

Legacy workflow tests export actual WPJ/SRV files and fresh caches, verify source line references and the original timestamp/name/size checksum, relocate the project and reopen/recompile it, edit source topology and preserve styles/views, and retain dynamic floats. They check segment inheritance and attachment without changing measurements, upgrade the older 348-byte NTA header, and retain the solver's unfixed origin when source grouping changes.

The original 185,142-byte Tutorial NTW parses and writes byte identically. Mask regeneration handles transformed curves, compound paths, holes, group records and colours; the original Illustrator Tutorial SVG regenerates its seven polygons and two group records. Curve subdivision is tolerance-based and is not a bit-identical transcription of the original tessellator. Stylesheets, clipping/filtering and unsupported primitives are rejected with conversion instructions.

Import tests cover eight-character SRV names, CP1252/CRLF output, SEF folder hierarchy, combined observations, source attachments, station-character replacement and collision checks, MAK links under replacement rules, `!TO` LRUD association, and Compass's fixed feet/degrees DAT storage independently of its display FORMAT. ZIP tests include compiled reviews and preserve project-local relative MAK/DAT attachments after relocation. Command-line tests exercise generation, rebuild, style editing, mask export and normalized original-project export.

The original executable was launched for acceptance checking, but the helper returned an all-black state and failed activation after recovery. Native acceptance of generated/rebuilt files and interactive acceptance of the 0.4 desktop therefore remain unverified. GPS and printing code was not extended in this release; existing regression checks still run.

## Limits

These tests do not prove full Walls 2.2.4 parity. A broader original-executable corpus, independent projection goldens, additional malformed/production data, interactive review edits, all desktop workflows, supported receiver hardware, printer output and clean-machine/platform checks remain outstanding. See [PARITY.md](PARITY.md) for known missing functionality.
