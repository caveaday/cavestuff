# Walls neXT 0.4.0

Rust survey engine and native desktop application based on Walls **v2.2.4**, commit `8428c2ba8ecde662753e4437b3f6d8ee1e783467`.

This application provides original workfile interoperability, a survey editor, 3D rendering, GPS import controls and printing. **Full Walls 2.2.4 parity is still incomplete.** Read [PARITY.md](PARITY.md) for remaining functionality and [VALIDATION.md](VALIDATION.md) for evidence and limits.

Version 0.4.0 generates fresh NTA/NTV/NTP/NTS/NTN workfiles from Rust compilations, exports normalized original review projects, recompiles changed sources while retaining segment styles/views, and rebuilds NTW artwork from existing SVG masks. Legacy import adds folder hierarchy, combined surveys, source attachments and station-name rules. ZIP archives can include compiled reviews. GPS and printing are unchanged in this release.

## Start the desktop

Extract the Windows package and run `walls-desktop.exe`. Use **Open** for SRV/WPJ or original NTV/NTP/NTA workfiles, then use the tool tabs:

| Tab | Workflow |
| --- | --- |
| Map | Plan/profile, bearing, segment filter, pan/zoom, station details |
| Survey editor | Keep multiple tabs; save all and compile; find/replace in one or all open documents; auto-sequence, reverse station names, comment/indent, go to line; choose encoding and line endings |
| Workfiles | Generate fresh bundles or normalized original review projects; recompile sources; edit saved views and segment attachment/styles; attach an updated SVG/NTW mask; save separate bundles |
| Review | Analyze variances and loop systems; select a traverse; float H/V or break its endpoint; undo/redo/reset; save a revision-checked review state |
| 3D | Build LRUD/wall-shot passages; orbit by dragging, pan with the right button, zoom with the wheel, fly using WASD/QE while pointing at the view; open/export textured VRML; choose smooth/flat/unlit/wireframe/hidden-line/points and mono/side-by-side/anaglyph stereo; save settings or export PNG; pick two stations to measure in mono |
| SVG | Create an adjustable map, edit its Walls/Detail artwork in an SVG editor, reopen it, adjust to the current survey, save the result |
| Print | Choose scale/paper, generate preview, save/load formats; set fonts, line widths, station marks, prefixes/heights and a segment filter; export PDF or the selected page as EMF/WMF; open the Windows printer dialog |
| GPS | Choose a serial port and baud rate; capture NMEA or download Garmin waypoints/tracks; open/save filtered GPX or CSV; restrict by named waypoint/radius, split track gaps, thin points, mark a live waypoint; create a referenced WPJ project |
| Project | Edit books, survey references, options, geography and detach flags; drag nodes into books; save and compile the entire project or a selected branch |
| Import / ZIP | Import SEF or Compass DAT/MAK with folder/combine/name/source options; create or extract project ZIPs with optional workfiles |

Review operations retain source files. Save review state explicitly to retain an experiment. A saved state applies only to the same survey revision. Hardware functions require a connected receiver/printer and are not covered by live-hardware tests.

SVG adjustment retains styles, definitions, unknown XML, manually positioned labels, symbols, notes and artwork. Keep the `w2d_Ref` and identified survey vectors intact in your SVG editor. Added stations receive vectors and labels; intentionally omitted labels on existing stations stay omitted. Review the adjusted artwork before using it as a final map.

For two-source merging, add a second artwork SVG in the desktop or use `--source2`. Both maps are adjusted to a common frame. Secondary artwork paints above primary artwork in the matching Walls layers; IDs and definition references are renamed to avoid collisions. Survey vectors, labels and flags come from the primary map once. Expand any secondary stylesheet rules to inline styles in your SVG editor first.

Printing offers styled flags, notes and an optional flag legend. Use `--no-flags` or `--no-notes` to hide map annotations, and `--report notes` to print all note/flag text separately. Measured length remains available in JSON; map summaries use adjusted length.

## Workfiles and editor saves

Open a closed original compiled project through its NTV, NTP or NTA file. Keep the same-stem files together. NTA provides prefix identities, segments, notes, flags, LRUD and saved views; NTS provides the saved H/V floating state; NTP supplies the stored adjusted coordinates. NTW/NTAC and unknown metadata inside supported files are retained. The **Workfiles** tab writes into a different directory and refuses to overwrite an existing bundle.

For a fresh compilation, use **Generate fresh workfiles**. To open it in original Walls, use **Export original review project**: this writes a WPJ, compatible eight-character SRV filenames and fresh caches in the project work directory. It retains measurements, prefixes, annotations, LRUD, spray shots, dates, float state and references. A small `.sources.json` sidecar records Rust source navigation; original Walls ignores it. Cache-only exports can use filename aliases; normalized project export supplies matching actual source files.

**Compile** on an imported bundle reloads its source WPJ/SRV. Save edited documents first. **Save workfiles with current review** preserves the existing bundle when observations are unchanged and rebuilds after source edits. Rebuilding retains segment styles by path, flag styles by name, saved views and NTAC gradients; it invalidates the old NTW cache. The segment panel supports attachment, inherited colours, line styles and station display flags. Segment detachment hides a map branch while retaining measurements. The separate Rust review option **Break endpoint** changes topology; restore synthetic endpoints before original workfile export.

Use **Attach updated SVG mask / NTW artwork** after adjusting the SVG to the new survey. This generates packed NTW point/polygon/group arrays from an existing plan `w2d_Mask` layer, including curves, holes, transforms and colours. Default curve tolerance is 5 mm. It does not construct a passage outline from an unmasked centerline. Expand stylesheet rules, clipped/filtered artwork, rounded rectangles and unsupported primitives into inline paths first. NTW JSON can also be saved/loaded through the CLI. Artwork must use the current survey frame.

Untouched copies remain byte identical. Generated files are checked against original schemas and fixtures, but acceptance of new/rebuilt bundles in the original application remains unverified: the desktop helper returned a black capture and then failed to activate the original window.

`examples/generated-review/TUTORIAL.wpj` is a normalized Tutorial review project written by this release. Its `TUTORIAL/` directory contains freshly generated workfiles and a regenerated SVG mask cache. It is separate from the unchanged upstream examples.

Survey tabs keep independent unsaved edits and undo histories while switching projects. Save detects changes made by another program; existing files are written through a temporary file and replaced after a successful write. Save As refuses an existing destination. Select a line range for reverse/comment/indent commands. Find supports case/whole-word options, selected text or all open documents, and clickable results. Auto-sequence follows the original adjacent numeric station-name convention, including reverse survey order. Regular-expression search and every original editor shortcut are not implemented.

## Viewer, GPS and print formats

VRML textures may be embedded SFImage/PixelTexture or local PNG/JPEG/BMP/TGA/TIFF files. Relative filenames resolve beside the VRML file; URL lists try local alternatives. UV indices, wrapping and 2D texture transforms are retained. VRML export embeds texture pixels. Emissive/specular colours and shininess survive export/reimport. Rendering clips at the near plane and uses perspective-correct colour/UV interpolation. Transparent faces are sorted; intersecting transparent surfaces and exact old OpenGL lighting remain compatibility limits. Viewer settings use Rust JSON, not the original Walls3D settings format.

Print presets use JSON. Command-line options override only explicitly supplied settings. PDF contains all pages by default; EMF/WMF exports one page and requires --page when the layout has multiple sheets. The Windows metafiles retain vector lines/text and physical page dimensions. Fonts use points; distances use metres or millimetres as labelled. Reports obey paper, orientation, margin and font settings and repeat the column heading on each page.

GPS settings are applied when saving/exporting or creating a project, so the downloaded dataset remains available. A blank restriction waypoint includes the whole area. Radius and track-break distances use the selected/default projected grid, matching the original import approach. Time bounds in settings are Unix UTC seconds; CSV may display a specified UTC offset in minutes. GPX accepts ISO8601 UTC or numeric timezone offsets. No receiver is connected, so hardware validation remains outstanding.

## Command line

Run `walls --help` for the complete syntax. Examples:

```powershell
walls check "examples/upstream/Tutorial Project/tutorial.wpj"
walls compile examples/loop.srv --format svg --output cave.svg
walls svg-merge examples/loop.srv cave.svg --output adjusted.svg
walls svg-merge examples/loop.srv cave.svg --source2 other-artwork.svg --output combined.svg
walls review examples/loop.srv --output review.json
walls compile examples/loop.srv --state survey.review.json --format wrl --output cave.wrl
walls print examples/loop.srv --scale 500 --paper a4 --output cave.pdf
walls print examples/loop.srv --report traverses --output traverses.pdf
walls print examples/loop.srv --legend --output map-with-legend.pdf
walls print examples/loop.srv --report notes --output annotations.pdf
walls import old-project.mak --attach-source --output converted
walls import old-surveys.sef --combine --name-settings examples/import-names.json --output combined
walls archive converted/project.wpj --workfiles --output project.zip
walls extract project.zip --output restored
walls gps-ports
walls gps-download COM3 --baud 9600 --output gps.gpx
walls gps-import gps.gpx --settings examples/gps-settings.json --output gps-project
walls gps-export gps.gpx --settings examples/gps-settings.json --output gps.csv
walls workfiles cave.wpj --name CAVE --output fresh-cache
walls workfiles cave.wpj --project --name CAVE --output original-review-project
walls workfiles fresh-cache/CAVE.NTV --rebuild --output rebuilt-cache
walls workfiles cave.wpj --name CAVE --mask updated-map.svg --output masked-cache
walls workfiles original/TUTORIAL.NTV --output copied-workfiles --save-views views.json
walls workfiles original/TUTORIAL.NTV --save-segments styles.json
walls workfiles original/TUTORIAL.NTV --state survey.review.json --view-state views.json --output reviewed-workfiles
walls print examples/loop.srv --settings examples/print-format.json --output formatted.pdf
walls print examples/loop.srv --page 1 --output sheet.emf
walls render3d examples/textured-room.wrl --mode smooth --output room.png
walls render3d examples/loop.srv --stereo side-by-side --output cave-stereo.png
walls utm 38 -90 15 --datum "NAD27 CONUS"
```

`compile --format` accepts `csv`, `vectors`, `json`, `svg`, `profile`, `dxf`, `shp`, `geojson`, `srv`, `sef`, `wrl`, and `review`. Shapefile output requires a filename and produces SHP/SHX/DBF/CPG/PRJ sidecars. `compile` and `review` accept `--branch 0/2` for zero-based project child indexes.

Internal distances are meters. Negative grid zones select the southern hemisphere; zones +/-61 select UPS. GeoJSON transforms a recognized project datum to WGS84. Shapefiles retain the original grid and datum with projection metadata. Geographic exports require survey coordinates that actually use the referenced grid. Datum conversions use the original three-translation algorithm rather than grid-shift datasets.

Import and extraction require empty destinations and refuse overwrites. Imports use Windows-1252, CRLF and eight-character SRV basenames. Station-name rules preserve colon prefixes or replace specified characters; collisions abort the import. Combined import checks that observations and dates survive normalization. Compass DAT physical columns remain feet/degrees regardless of FORMAT display preferences. MAK imports retain file namespaces and explicit links, including fixed points in different zones/datums and `!TO` LRUD association. Original sources are auxiliary project nodes. Project-local relative attachment paths survive ZIP relocation; unreferenced dependencies and absolute links inside attachments are not rewritten. `archive --workfiles` also includes existing compiled reviews and artwork; extracted source timestamps can make original Walls recompile its caches.

## Build and verify

Use a stable Rust toolchain with its platform linker:

```powershell
cargo build --release --locked --features desktop
cargo test --locked
cargo clippy --locked --all-targets --all-features -- -D warnings
cargo fmt --all -- --check
```

The desktop is optional. `cargo build --release --locked` builds the CLI and engine. This package was tested on Windows x64 GNU with Rust 1.99.1; Linux/macOS and Windows MSVC have not been exercised here. Native printer integration is Windows-only; PDF export is platform-independent.

Application and survey processing code is Rust; the application does not load original Walls DLLs. Source modules include `parser`, `units`, `project`, `project_edit`, `adjust`, `review`, `svgmap`, `scene`, `render3d`, `vrml`, `gps`, `gps_filter`, `print`, `print_gdi`, `editor`, `workfiles`, `exchange`, `compass_project`, `geodesy`, `magnetic`, `export`, and the desktop tools. See [NOTICE.md](NOTICE.md) for attribution.
